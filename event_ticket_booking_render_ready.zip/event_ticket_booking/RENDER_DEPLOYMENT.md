# Eventify - Render deployment notes

## Runtime
This is a PHP + MySQL application. Deploy it as a **Render Web Service** using the **Docker** language/runtime. It is not a Static Site.

## Render settings
- Repository: `SpandanaM04/tickets_booking`
- Branch: `main`
- Root Directory: leave blank (the PHP files and Dockerfile are at repository root)
- Language: Docker
- Dockerfile Path: `./Dockerfile`
- Docker Command: leave blank
- Port: Apache listens on `10000`

## Database configuration
The application uses MySQLi. `db.php` keeps the XAMPP defaults for local development and reads these environment variables when deployed:

- `DB_HOST`
- `DB_USER`
- `DB_PASSWORD`
- `DB_NAME`
- `DB_PORT` (usually `3306`)

Create an externally hosted MySQL database, import your own database export, then add the credentials as environment variables in Render. Do not commit database passwords or SQL exports to a public repository.

## Database schema required by the current PHP code
The code expects at least:
- `users`: `id`, `name`, `email`, `password`
- `events`: `id`, `title`, `description`, `category`, `event_date`, `event_time`, `venue`, `city`, `price`, `available_tickets`, `image`
- `bookings`: `id`, `booking_ref`, `event_id`, `customer_name`, `email`, `phone`, `quantity`, `total_amount`, and a `booking_date` column used by the dashboard (ideally with a default timestamp)

The ZIP supplied for this deployment did not contain a `.sql` export, so the actual database schema and event records must be exported from phpMyAdmin and imported into the hosted MySQL database separately.

## Local testing
Keep using XAMPP locally. The default connection in `db.php` is `localhost`, user `root`, blank password, database `event_booking`. Change the database name if your local phpMyAdmin database has a different name.
